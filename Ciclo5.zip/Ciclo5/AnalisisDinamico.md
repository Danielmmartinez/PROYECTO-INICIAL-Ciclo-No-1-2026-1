Durante el desarrollo y la refactorización del proyecto, el análisis dinámico (evaluación del software en tiempo de ejecución) fue fundamental para garantizar que la nueva arquitectura basada en principios SOLID no afectara el rendimiento ni la corrección funcional del sistema.

### 1. Ejecución y Validación de Pruebas (JUnit 4)
Se ejecutó de manera continua una suite exhaustiva de pruebas unitarias, de integración y de aceptación. 
* **Comportamiento Polimórfico en Tiempo Real:** Al eliminar las condicionales estáticas (`instanceof`, `isCup()`) y delegar el comportamiento dinámico a cada objeto, las pruebas confirmaron que las piezas (`Cup`, `Lid`, `OpenerCup`, `FearfulLid`) reaccionan y calculan sus propias físicas de colisión de forma precisa en tiempo de ejecución.
* **Resultado:** El 100% de las pruebas se ejecutan de manera exitosa (Verde), confirmando que no hay regresiones lógicas tras la reestructuración profunda.

### 2. Rendimiento y Manejo de Memoria
Se prestó especial atención a la eficiencia del sistema, evaluando dos frentes críticos durante la ejecución:
* **El Simulador de Algoritmos (`TowerContest`):** El método de resolución por fuerza bruta (DFS) evalúa miles de combinaciones en milisegundos. Para evitar una sobrecarga de memoria (*Heap Exhaustion*) y bloqueos por el *Garbage Collector* al instanciar masivamente objetos complejos, el motor interno del simulador se mantuvo optimizado utilizando estructuras de datos primitivas (`int[]`).
* **Eficiencia del Renderizado (`TowerRenderer`):** El redibujado de la torre se optimizó aplicando un ordenamiento dinámico por capas (Z-Index a través de `getRenderLayer()`), asegurando que la interfaz gráfica superponga los elementos (tazas al fondo, tapas al frente) sin necesidad de repintados innecesarios.

### 3. Correcciones Derivadas del Análisis Dinámico
La observación directa del sistema en ejecución nos permitió detectar y corregir anomalías que el análisis estático no evidenciaba:
* **Prevención de Condiciones de Carrera (Race Conditions):** Se detectó que el acceso concurrente al `Canvas` podía ser inestable, por lo que se aplicó el modificador `synchronized` al patrón Singleton gráfico, garantizando un entorno *Thread-Safe* durante las pruebas automatizadas.
* **Aislamiento Gráfico (Fix de "Ghosting"):** Durante la ejecución en lote de las pruebas gráficas, se evidenció que los objetos visuales de pruebas anteriores permanecían en memoria y en pantalla. Esto se solucionó inyectando un método `reset()` en el ciclo de vida del constructor de `Tower`, lo que asegura una limpieza profunda de la memoria del lienzo (limpiando mapas y listas internas) cada vez que inicia un nuevo contexto de prueba.