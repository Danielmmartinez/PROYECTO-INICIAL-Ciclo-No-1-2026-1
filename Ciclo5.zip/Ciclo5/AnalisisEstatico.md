El análisis estático del código se llevó a cabo utilizando la herramienta **PMD**, con el objetivo de detectar *code smells*, posibles vulnerabilidades y asegurar el cumplimiento de estándares de codificación limpios sin necesidad de ejecutar el programa.

A través de este proceso, se identificaron y corrigieron múltiples advertencias que elevaron la calidad técnica del proyecto:

### 1. Prevención de Errores y Seguridad (Bug Prevention)
* **Null-Safety (Condiciones Yoda):** Se reestructuraron las comparaciones de cadenas (Strings) para colocar los literales a la izquierda (ej. `"cup".equals(obj.getCategory())` en lugar de `obj.getCategory().equals("cup")`). Esto es una práctica estándar en la industria para prevenir excepciones de tipo `NullPointerException`.
* **Manejo de Excepciones:** Se eliminaron los bloques `catch` vacíos (específicamente en la clase `Canvas`), añadiendo trazas de error básicas para evitar que las interrupciones de los hilos pasaran desapercibidas (Fail-fast).

### 2. Diseño Orientado a Objetos y Encapsulamiento
* **Protección de Clases Utilitarias:** Clases diseñadas exclusivamente para proveer métodos estáticos (como `TowerFactory` y `TowerContest`) fueron marcadas como `final` y se les asignó un constructor privado. Esto asegura que no puedan ser instanciadas ni heredadas por error, protegiendo la arquitectura.
* **Abstracción sobre Implementación:** Se corrigieron declaraciones de colecciones para depender de interfaces en lugar de implementaciones concretas (ej. declarar `Map` en lugar de `HashMap` en el `Canvas`), cumpliendo con los principios de diseño flexible.

### 3. Limpieza de Código y Estilo (Clean Code)
* **Estructuras de Control:** Se añadieron llaves `{}` obligatorias en todos los bloques `if`, `else` y `for` de una sola línea a lo largo de todo el proyecto, eliminando ambigüedades y previniendo errores futuros de indentación.
* **Optimización de Imports y Variables:** Se eliminaron variables de estado declaradas pero no utilizadas (como `width` en la clase `Tower`) y se purgaron los *wildcard imports* (`import shapes.*;`), reemplazándolos por importaciones explícitas para reducir la carga de la clase.
* **Convenciones de Nombrado:** Se refactorizaron los nombres de los métodos de prueba en JUnit 4 (ej. `TowerCC2Test`) para cumplir con el estándar `camelCase` (iniciando en minúscula), lo cual es exigido por las convenciones de Java.

### 4. Falsos Positivos Documentados
Durante el análisis, se tomó la decisión arquitectónica consciente de ignorar la advertencia *“Unnecessary qualifier 'java.awt'”*. Dado que el dominio del problema requiere una clase propia llamada `Shape`, el uso del cualificador explícito `java.awt.Shape` es estrictamente necesario en las clases base para evitar colisiones de *namespaces* (nombres) con la librería nativa de Java.