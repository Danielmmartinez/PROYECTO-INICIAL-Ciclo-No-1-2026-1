import java.util.*;
import javax.swing.JOptionPane;

public class Tower {
    private int width, maxHeight;
    private boolean isVisible, lastOperationOk;
    private HashMap<Integer, Cup> cups;
    private HashMap<Integer, Lid> lids;
    private ArrayList<Object> stackedElements;
    private ArrayList<Rectangle> rulerMarks;

    public Tower(int width, int maxHeight) {
        this.width = width;
        this.maxHeight = maxHeight;
        this.cups = new HashMap<>();
        this.lids = new HashMap<>();
        this.stackedElements = new ArrayList<>();
        this.rulerMarks = new ArrayList<>();
        this.lastOperationOk = true;
    }

    // --- MÉTODOS DE TAZAS ---
    public void pushCup(int i) {
        if (cups.containsKey(i)) {
            lastOperationOk = false;
            reportError("La taza " + i + " ya existe.");
            return;
        }
        Cup c = new Cup(i);
        if (checkHeight(c)) {
            cups.put(i, c);
            stackedElements.add(c);
            lastOperationOk = true;
            updateView();
        }
    }

    public void popCup() {
        lastOperationOk = false;
        for (int j = stackedElements.size() - 1; j >= 0; j--) {
            if (stackedElements.get(j) instanceof Cup) {
                Cup c = (Cup) stackedElements.remove(j);
                cups.remove(c.getId());
                c.makeInvisible();
                lastOperationOk = true;
                updateView();
                break;
            }
        }
    }

    public void removeCup(int i) {
        if (cups.containsKey(i)) {
            Cup c = cups.remove(i);
            c.makeInvisible();
            stackedElements.remove(c);
            lastOperationOk = true;
            updateView();
        } else { lastOperationOk = false; }
    }

    // --- MÉTODOS DE TAPAS ---
    public void pushLid(int i) {
        if (lids.containsKey(i)) { lastOperationOk = false; return; }
        Lid l = new Lid(i);
        if (cups.containsKey(i)) l.setColor(cups.get(i).getColor());
        
        if (checkHeight(l)) {
            lids.put(i, l);
            stackedElements.add(l);
            lastOperationOk = true;
            updateView();
        }
    }

    public void popLid() {
        lastOperationOk = false;
        for (int j = stackedElements.size() - 1; j >= 0; j--) {
            if (stackedElements.get(j) instanceof Lid) {
                Lid l = (Lid) stackedElements.remove(j);
                lids.remove(l.getId());
                l.makeInvisible();
                lastOperationOk = true;
                updateView();
                break;
            }
        }
    }

    public void removeLid(int i) {
        if (lids.containsKey(i)) {
            Lid l = lids.remove(i);
            l.makeInvisible();
            stackedElements.remove(l);
            lastOperationOk = true;
            updateView();
        } else { lastOperationOk = false; }
    }

    // --- LÓGICA DE TORRE ---
    public void orderTower() {
        List<Integer> ids = new ArrayList<>(cups.keySet());
        Collections.sort(ids, Collections.reverseOrder());
        stackedElements.clear();
        for (int id : ids) {
            stackedElements.add(cups.get(id));
            if (lids.containsKey(id)) stackedElements.add(lids.get(id));
        }
        updateView();
        lastOperationOk = true;
    }

    public void reverseTower() {
        Collections.reverse(stackedElements);
        updateView();
        lastOperationOk = true;
    }

    public int height() {
        int currentTopY = 280, currentBaseY = 280, lastId = Integer.MAX_VALUE;
        for (Object obj : stackedElements) {
            if (obj instanceof Cup) {
                Cup c = (Cup) obj;
                int y = (c.getId() < lastId) ? currentBaseY - (c.getHeight() * 10) : currentTopY - (c.getHeight() * 10);
                currentTopY = Math.min(currentTopY, y);
                currentBaseY = y + (c.getHeight() * 10) - 10;
                lastId = c.getId();
            } else if (obj instanceof Lid) {
                currentTopY -= 10;
                currentBaseY = currentTopY;
                lastId = 0;
            }
        }
        return (280 - currentTopY) / 10;
    }

    private boolean checkHeight(Object potential) {
        ArrayList<Object> temp = new ArrayList<>(stackedElements);
        temp.add(potential);
        // Simulación rápida de altura
        int topY = 280, baseY = 280, lastId = Integer.MAX_VALUE;
        for (Object obj : temp) {
            if (obj instanceof Cup) {
                Cup c = (Cup) obj;
                int y = (c.getId() < lastId) ? baseY - (c.getHeight()*10) : topY - (c.getHeight()*10);
                topY = Math.min(topY, y);
                baseY = y + (c.getHeight()*10) - 10;
                lastId = c.getId();
            } else { topY -= 10; baseY = topY; lastId = 0; }
        }
        if ((280 - topY) / 10 > maxHeight) {
            reportError("Excede la altura máxima de " + maxHeight + " cm");
            lastOperationOk = false;
            return false;
        }
        return true;
    }

    public int[] lidedCups() {
        ArrayList<Integer> res = new ArrayList<>();
        for (Integer id : cups.keySet()) if (lids.containsKey(id)) res.add(id);
        Collections.sort(res);
        return res.stream().mapToInt(i -> i).toArray();
    }

    public String[][] stackingItems() {
        String[][] items = new String[stackedElements.size()][2];
        for (int i = 0; i < stackedElements.size(); i++) {
            Object o = stackedElements.get(i);
            items[i][0] = (o instanceof Cup) ? "cup" : "lid";
            items[i][1] = String.valueOf((o instanceof Cup) ? ((Cup)o).getId() : ((Lid)o).getId());
        }
        return items;
    }

    // --- VISIBILIDAD Y SISTEMA ---
    private void updateView() {
        if (!isVisible) return;
        int currentBaseY = 280, currentTopY = 280, lastId = Integer.MAX_VALUE;
        for (Object obj : stackedElements) {
            if (obj instanceof Cup) {
                Cup c = (Cup) obj;
                int y = (c.getId() < lastId) ? currentBaseY - (c.getHeight()*10) : currentTopY - (c.getHeight()*10);
                c.setPosition(150 - (c.getId()*5), y);
                c.makeVisible();
                currentTopY = Math.min(currentTopY, y);
                currentBaseY = y + (c.getHeight()*10) - 10;
                lastId = c.getId();
            } else if (obj instanceof Lid) {
                Lid l = (Lid) obj;
                int y = currentTopY - 10;
                l.setPosition(150 - (l.getId()*5), y);
                l.makeVisible();
                currentTopY = y; currentBaseY = y; lastId = 0;
            }
        }
    }

    public void makeVisible() { Canvas.getCanvas().setVisible(true); isVisible = true; drawRuler(); updateView(); }
    public void makeInvisible() { isVisible = false; } // Implementar borrado si es necesario
    public void exit() { System.exit(0); }
    public boolean ok() { return lastOperationOk; }

    private void drawRuler() {
        for (Rectangle r : rulerMarks) r.makeInvisible();
        rulerMarks.clear();
        for (int i = 0; i <= maxHeight; i++) {
            Rectangle m = new Rectangle();
            m.changeSize(1, 10); m.changeColor("black");
            m.moveHorizontal(40 - 70); m.moveVertical((280 - (i*10)) - 15);
            m.makeVisible();
            rulerMarks.add(m);
        }
    }

    private void reportError(String m) { if (isVisible) JOptionPane.showMessageDialog(null, m); }
}